# 实验方案摘录（整理稿，不是原始计划）

来源：Max Häußler, *From raw data to kinetic parameters: an EnzymeML-based workflow for reproducible enzyme kinetics*, Scenario D notebook `enzyme_inactivation.ipynb`。数据 DOI: https://doi.org/10.18419/DARUS-3337；记录许可 CC BY 4.0。整理者从原文方案段摘录并重排，未添加实验事实。

## CotA 吸附失活测量
CotA laccase（*Bacillus subtilis*）在单独的 96 孔聚苯乙烯微孔板孔中预孵育，最长 1 小时；每隔 10 分钟启动一组反应，将 2 µL 已孵育酶液转入新的反应孔。反应终浓度为 256 nM CotA、1 mM ABTS，乙酸缓冲液 pH 4。25°C、420 nm 监测产物形成 5 分钟，技术三重复。ABTS 自由基产物浓度按 ε=36000 M⁻¹ cm⁻¹ 计算。

此方案考察的是预孵育后的相对活性衰减；不能与并行的长时底物动力学实验混为同一实验。来源 notebook 提示初始测量存在混合或不确定性问题；该疑点应在审阅中保留，不预先提供处理结论。


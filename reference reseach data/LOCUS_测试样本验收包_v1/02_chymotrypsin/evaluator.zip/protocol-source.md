# Protocol source excerpt

This is a source-derived protocol summary from `book/scenarios/chymotrypsin_inhibition.ipynb`, cell 0, heading “Experimental design”. It is a curated excerpt, not an experiment log or newly created measurement record.

The authors monitored chymotrypsin activity photometrically by measuring p-nitroaniline product at 410 nm for 30 minutes at 30 °C. Succinyl-gly-gly-phe-p-nitroanilide (SGGPpNA) was used as substrate over 0.25–2 mM. A p-NA standard curve spanning 0–0.3 mM was measured in duplicate. Each reaction contained 0.2 µM enzyme; inhibitor reactions additionally contained 26.88 µM of the relevant HSA variant. HSA(WT)-huFc and HSA(M3)-huFc inhibition experiments were independent, each with reactions with and without inhibitor; each reaction was prepared in duplicate. Experimental and metadata were entered into EnzymeML Excel templates, while calibration was stored in Excel files. The notebook says the measurement data had already been blanked.

Source: DaRUS-3337, DOI [10.18419/DARUS-3337](https://doi.org/10.18419/DARUS-3337), CC BY 4.0. Related measurement files: `data/chymotrypsin_inhibition/chymo_HSAwt.xlsx`, `chymo_HSA(M3).xlsx`, and `pNA-standard.xlsx`.

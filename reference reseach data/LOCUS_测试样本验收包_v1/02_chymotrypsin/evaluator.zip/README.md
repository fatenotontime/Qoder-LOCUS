# Locus evaluator materials

DaRUS-3337, CC BY 4.0. This case uses experimental chymotrypsin inhibition measurements. The included workbook values are already blanked; they are not instrument-native raw acquisitions. Do not simulate blank correction. Keep the negative first M3 measurement intact in source review: the author's analysis excluded that point from fitting, but the workbook value remains evidence to inspect.

The three plots in `author_outputs/` are small original-author output extracts. Treat them as external artifacts a user may submit later for review. Do not automatically load them into the model context or treat them as authoritative answers.

## Five-step Locus workflow

1. Import the public study as a project and create a sub-question for comparing HSA(WT)-huFc and HSA(M3)-huFc inhibition of chymotrypsin. Record the source DOI and CC BY 4.0 attribution.
2. Add the experiment description from `protocol-source.md` as a method record; inspect its source and conditions card, then relate the three workbooks to the method. Initial import excludes the author plots; keep them outside model context until the evaluator decides to submit them.
3. Use the experiment map to connect calibration, WT and M3 measurement records, and the analysis question. Submit a short analysis deliverable stating what the evidence supports and what remains uncertain.
4. Draft a result, then return to the original M3 workbook and check the first negative measurement. Record the author's stated exclusion separately from your own decision; revise and request review if needed.
5. Export the project evidence and analysis. If a user separately submits an author plot, review it against the source measurements and protocol; do not assume it is a gold standard.

The source notebook and its answer narrative are developer reference only and are absent from the evaluator package. Initial model input must not include the author plots or later user-submitted outputs unless the evaluator explicitly chooses to submit them.

